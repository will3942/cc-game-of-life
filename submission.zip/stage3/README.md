# cc-game-of-life
Live love laugh
